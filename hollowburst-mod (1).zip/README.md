# Hollow Burst (Forge 1.21.1)

Press **C** to detonate yourself skyward in a Gojo-style cutscene (Reversal: Red).
While airborne (20 s window, configurable):

- **Mace hit** -> *Hollow Purple* (the big one: orbs merge, time stop, huge impact)
- **Sword hit** -> *Lapse: Blue* (pull everything in, freeze, double slash)

Every cutscene is a scripted, multi-shot film:
- a real free camera (orbits, cranes, push-ins, whip cuts, wall-aware), not a third-person hack
- glowing world-space energy: charge cores, blast spheres, shockwave rings, crossing blue slashes,
  orbiting red/blue orbs, a purple sphere and a sky beam, plus visual-only lightning
- giant kanji title cards (赫 / 蒼 / 茈) that slam in with a shake
- letterbox bars, typewriter subtitles, vignette, speed lines, fades
- anime impact frames (real colour inversion + speed lines + star burst), zoom punches, roll, shake
- custom body animation for the caster (hover, lean, twist, hand-to-eye, arms thrust, sword overhead),
  visible to other players too, armour and held items follow

## Build
    ./gradlew build        # jar ends up in build/libs/
Needs JDK 21. Forge 52.1.0 (change `forge_version` in gradle.properties if you want a newer 52.1.x).
GitHub Actions: push this folder as the repo root, `.github/workflows/build.yml` does the rest.

## Tweak
- `config/hollowburst-common.toml`: cooldown, launch speed, damage, block destruction.
- `assets/hollowburst/lang/en_us.json`: subtitle text.
- `client/CutsceneDefs.java`: all timings, camera shots, FOV/roll/shake curves, impact frames, titles.
- `client/PlayerAnims.java`: the body choreography (keyframes per cutscene).
- `client/WorldFx.java`: the glowing world effects (spheres, rings, beam, slashes).
- `server/AbilityManager.java`: the gameplay side of each sequence (tick based, 20 ticks = 1 s).
- Rebind the key in Options > Controls > Hollow Burst.
