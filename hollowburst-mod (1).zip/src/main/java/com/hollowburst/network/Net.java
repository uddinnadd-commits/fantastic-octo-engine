package com.hollowburst.network;

import com.hollowburst.HollowBurstMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.SimpleChannel;

public final class Net {
    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(HollowBurstMod.MODID, "main"))
            .networkProtocolVersion(1)
            .simpleChannel();

    private static boolean registered = false;

    public static void init() {
        if (registered) return;
        registered = true;

        CHANNEL.messageBuilder(ActivatePacket.class, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ActivatePacket::encode)
                .decoder(ActivatePacket::decode)
                .consumerMainThread(ActivatePacket::handle)
                .add();

        CHANNEL.messageBuilder(CutscenePacket.class, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(CutscenePacket::encode)
                .decoder(CutscenePacket::decode)
                .consumerMainThread(CutscenePacket::handle)
                .add();
    }

    private Net() {}
}
