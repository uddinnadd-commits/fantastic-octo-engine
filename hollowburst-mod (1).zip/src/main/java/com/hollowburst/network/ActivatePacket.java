package com.hollowburst.network;

import com.hollowburst.server.AbilityManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Client -> server: the player pressed the ability key. */
public class ActivatePacket {
    public ActivatePacket() {}

    public static void encode(ActivatePacket msg, FriendlyByteBuf buf) {
        // nothing to write
    }

    public static ActivatePacket decode(FriendlyByteBuf buf) {
        return new ActivatePacket();
    }

    public static void handle(ActivatePacket msg, CustomPayloadEvent.Context ctx) {
        ServerPlayer sender = ctx.getSender();
        if (sender != null) {
            AbilityManager.tryActivate(sender);
        }
    }
}
