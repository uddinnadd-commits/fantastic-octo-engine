package com.hollowburst.client;

import com.hollowburst.CutsceneType;
import net.minecraft.client.CameraType;
import net.minecraft.world.phys.Vec3;

import static com.hollowburst.client.CutsceneDef.BLACK;
import static com.hollowburst.client.CutsceneDef.INVERT;
import static com.hollowburst.client.CutsceneDef.WHITE;
import static com.hollowburst.client.ShotEnv.lerp;
import static com.hollowburst.client.ShotEnv.mix;

/**
 * The three cutscenes. All times are milliseconds from the moment the cutscene starts.
 * The server runs the gameplay on a 50 ms tick clock, so the big moments line up:
 *   BURST: explosion at 1200 ms     SWORD: slash at 2000 ms     MACE: purple impact at 3900 ms
 *
 * Shots are small functions: they get a ShotEnv (progress, attacker, target, orb, directions) and
 * return a camera position + look-at point. Edit them freely. e.around(center, angle, radius, height)
 * puts the camera on a circle: angle 0 = behind the action, 90 = side, 180 = in front.
 */
public final class CutsceneDefs {

    private static final int RED = 0xFF4455;
    private static final int BLUE = 0x5CA8FF;
    private static final int PURPLE = 0xC27CFF;
    private static final int WHITE_TEXT = 0xFFFFFF;

    public static CutsceneDef get(CutsceneType type) {
        return switch (type) {
            case BURST -> burst();
            case SWORD -> sword();
            case MACE -> mace();
        };
    }

    /** Face close-up from the front, slowly pushing in. */
    private static CamPose eyes(ShotEnv e, double from, double to, double fov0, double fov1, double roll0, double roll1) {
        Vec3 look = e.head.add(0, -0.05, 0);
        Vec3 pos = e.head.add(e.fwd.scale(lerp(from, to, e.k))).add(0, 0.08, 0);
        return CamPose.of(pos, look, lerp(fov0, fov1, e.k), lerp(roll0, roll1, e.k));
    }

    /** A fixed spot on the ground behind the launch point, used to watch the ascent. */
    private static Vec3 ascentAnchor(ShotEnv e, double extraUp) {
        return e.origin.add(e.fwd.scale(-7.0)).add(e.side.scale(2.0)).add(0, 1.0 + extraUp, 0);
    }

    // ------------------------------------------------------------------ C key: Reversal: Red

    private static CutsceneDef burst() {
        return new CutsceneDef(2900)
                .freeze(1800)
                // free-camera shots
                .shot(0, 750, e -> eyes(e, 1.5, 0.85, 0.85, 0.6, -4, 3))
                .shot(750, 1200, e -> CamPose.of(
                        e.around(e.chest, lerp(70, 40, e.k), lerp(3.8, 2.3, e.k), -0.9),
                        e.head.add(0, 0.1, 0), lerp(0.8, 0.6, e.k), lerp(6, 10, e.k)))
                .shot(1200, 1560, e -> CamPose.of(
                        e.around(e.chest, lerp(40, -35, e.k), lerp(2.3, 6.5, e.k), lerp(-0.4, 0.6, e.k)),
                        e.chest, lerp(0.9, 1.35, e.k), lerp(10, -6, e.k)))
                .shot(1560, 2400, e -> CamPose.of(ascentAnchor(e, 0), e.head, 0.55, lerp(-6, 4, e.k)))
                .shot(2400, 2900, e -> CamPose.of(ascentAnchor(e, lerp(0, 5, e.k)), e.head, lerp(0.55, 0.8, e.k), 0))
                // fallback if the free camera can't start
                .cut(0, CameraType.THIRD_PERSON_FRONT)
                .cut(1250, CameraType.THIRD_PERSON_BACK)
                .fov(Curves.keys(
                        0, 1.0,
                        1150, 1.0,
                        1180, 0.82,
                        1290, 1.22,
                        1700, 1.0,
                        2900, 1.0))
                .roll(Curves.keys(0, 0, 1150, 0, 1160, -5, 1300, 6, 1800, 0))
                .shake(Curves.keys(
                        0, 0,
                        500, 0,
                        1150, 0.9,
                        1160, 3.2,
                        1700, 1.3,
                        2500, 0))
                .tint(0xFF1020, Curves.keys(0, 0, 800, 0.10, 1150, 0.28, 1300, 0.0, 2900, 0.0))
                .flash(1200, 450, 0xFFFFFF)
                .impact(1110, 55, 11, INVERT, WHITE, BLACK)
                .impact(1270, 60, 12, INVERT, BLACK)
                .lines(1200, 450, 0xFFFFFF)
                .title(1190, 2500, "title.hollowburst.red.kanji", "title.hollowburst.red.name", RED)
                .sub(200, 1000, "subtitle.hollowburst.red_1", WHITE_TEXT, 1.5f, false)
                .sub(900, 1950, "subtitle.hollowburst.red_2", RED, 1.8f, true);
    }

    // ------------------------------------------------------------------ sword hit: Lapse: Blue

    private static CutsceneDef sword() {
        return new CutsceneDef(3900)
                .freeze(3300)
                // 1: wide orbit around the pair while mobs get sucked into the vortex
                .shot(0, 1250, e -> {
                    Vec3 mid = mix(e.head, e.focus, 0.5);
                    return CamPose.of(e.around(mid, lerp(20, 80, e.k), lerp(7.5, 5.0, e.k), lerp(2.4, 1.3, e.k)),
                            e.focus, lerp(1.0, 0.8, e.k), lerp(0, 5, e.k));
                })
                // 2: tight on the target as everything freezes
                .shot(1250, 1700, e -> CamPose.of(
                        e.focus.add(e.fwd.scale(-lerp(3.2, 2.2, e.k))).add(e.side.scale(0.8)).add(0, 0.3, 0),
                        e.focus.add(0, 0.2, 0), 0.6, lerp(-4, 4, e.k)))
                // 3: the attacker's eyes
                .shot(1700, 2000, e -> eyes(e, 1.8, 1.2, 0.6, 0.5, 6, 10))
                // 4: side-on for the slash
                .shot(2000, 2450, e -> CamPose.of(
                        mix(e.head, e.focus, 0.5).add(e.side.scale(7.0)).add(0, 1.2, 0),
                        e.focus, lerp(1.25, 1.0, e.k), -8))
                // 5: slow pull-out orbit around the aftermath
                .shot(2450, 3300, e -> CamPose.of(
                        e.around(e.focus, lerp(90, 210, e.k), lerp(5, 10, e.k), lerp(1.5, 4.5, e.k)),
                        e.focus, 1.0, lerp(-6, 0, e.k)))
                // 6: back to the attacker
                .shot(3300, 3900, e -> eyes(e, 1.9, 1.4, 0.85, 0.9, 0, 0))
                .cut(0, CameraType.THIRD_PERSON_BACK)
                .cut(1900, CameraType.THIRD_PERSON_FRONT)
                .cut(2700, CameraType.THIRD_PERSON_BACK)
                .fov(Curves.keys(
                        0, 1.0,
                        1240, 1.0,
                        1255, 0.8,
                        1400, 1.0,
                        1990, 1.0,
                        2005, 0.78,
                        2120, 1.25,
                        2500, 1.0,
                        3900, 1.0))
                .roll(Curves.keys(0, 0, 1990, 0, 2000, -6, 2100, 7, 2800, 0))
                .shake(Curves.keys(
                        0, 0,
                        800, 0.4,
                        1250, 0.9,
                        1260, 2.5,
                        1500, 0.5,
                        1990, 0.5,
                        2000, 4.0,
                        2500, 1.2,
                        3300, 0))
                .tint(0x1A5CFF, Curves.keys(
                        0, 0,
                        600, 0.18,
                        1250, 0.28,
                        1900, 0.30,
                        2000, 0.0,
                        3900, 0.0))
                .flash(1250, 250, 0xBBDDFF)
                .flash(2000, 450, 0xE8F4FF)
                .impact(1245, 50, 21, INVERT, WHITE)
                .impact(1990, 45, 22, INVERT, WHITE, BLACK, INVERT, WHITE)
                .impact(2160, 60, 23, BLACK, INVERT)
                .lines(1700, 300, 0xCFE8FF)
                .lines(2000, 200, 0xFFFFFF)
                .title(1990, 3200, "title.hollowburst.blue.kanji", "title.hollowburst.blue.name", BLUE)
                .sub(150, 1150, "subtitle.hollowburst.blue_1", WHITE_TEXT, 1.5f, false)
                .sub(1150, 1950, "subtitle.hollowburst.blue_2", BLUE, 1.8f, true)
                .sub(2500, 3500, "subtitle.hollowburst.blue_3", WHITE_TEXT, 1.5f, false);
    }

    // ------------------------------------------------------------------ mace hit: Hollow Purple

    private static CutsceneDef mace() {
        return new CutsceneDef(6300)
                .freeze(5100)
                // 1: slow push-in on the face
                .shot(0, 1300, e -> eyes(e, 1.7, 0.9, 0.8, 0.55, -3, 3))
                // 2: orbit the red and blue orbs as they spiral together
                .shot(1300, 3000, e -> CamPose.of(
                        e.around(e.orb, lerp(-10, 190, e.k), lerp(4.2, 2.0, e.k), lerp(0.6, 0.1, e.k)),
                        e.orb, lerp(0.9, 0.65, e.k), lerp(-3, 6, e.k)))
                // 3: macro on the merge
                .shot(3000, 3300, e -> CamPose.of(
                        e.orb.add(e.side.scale(1.4)).add(e.fwd.scale(-0.6)).add(0, 0.2, 0),
                        e.orb, 0.6, lerp(4, 0, e.k)))
                // 4: ride behind the purple orb as it flies into the target
                .shot(3300, 3900, e -> {
                    double fly = Curves.smooth((e.t - 3000) / 900.0);
                    Vec3 orbPos = mix(e.orb, e.focus, fly);
                    Vec3 pos = orbPos.add(e.fwd.scale(-lerp(3.0, 3.4, e.k))).add(e.side.scale(1.2)).add(0, 0.7, 0);
                    return CamPose.of(pos, mix(orbPos, e.focus, 0.6), 0.75, lerp(0, -6, e.k));
                })
                // 5: violent dolly-out as the sphere expands
                .shot(3900, 4650, e -> CamPose.of(
                        e.around(e.focus, lerp(30, -10, e.k), lerp(5, 16, e.k), lerp(0.4, 2.0, e.k)),
                        e.focus.add(0, lerp(0, 4, e.k), 0), lerp(0.5, 1.6, e.k), lerp(-8, 4, e.k)))
                // 6: high crane over the crater
                .shot(4650, 5650, e -> CamPose.of(
                        e.focus.add(e.fwd.scale(-lerp(6, 12, e.k))).add(e.side.scale(lerp(0, 6, e.k))).add(0, lerp(14, 22, e.k), 0),
                        mix(e.focus, e.head, 0.4), 1.0, lerp(0, 5, e.k)))
                // 7: the attacker's face, final beat
                .shot(5650, 6300, e -> eyes(e, 1.8, 1.3, 0.7, 0.8, 0, 0))
                .cut(0, CameraType.THIRD_PERSON_FRONT)
                .cut(1500, CameraType.THIRD_PERSON_BACK)
                .cut(4650, CameraType.THIRD_PERSON_FRONT)
                .fov(Curves.keys(
                        0, 1.0,
                        2940, 1.0,
                        2950, 0.8,
                        3050, 1.15,
                        3300, 1.0,
                        3880, 1.0,
                        3890, 0.75,
                        4000, 1.3,
                        4400, 1.0,
                        6300, 1.0))
                .roll(Curves.keys(0, 0, 3880, 0, 3890, -10, 4000, 9, 4500, 0))
                .shake(Curves.keys(
                        0, 0,
                        1500, 0.3,
                        2900, 1.2,
                        2910, 3.5,
                        3880, 1.5,
                        3890, 6.0,
                        4300, 3.0,
                        5000, 0.6,
                        5600, 0))
                .tint(0x8A2BE2, Curves.keys(
                        0, 0,
                        2900, 0.0,
                        3050, 0.25,
                        3880, 0.38,
                        3900, 0.0,
                        6300, 0.0))
                .flash(2950, 500, 0xE0B0FF)
                .flash(3890, 700, 0xFFFFFF)
                .impact(2940, 60, 31, INVERT, WHITE, BLACK)
                .impact(3880, 50, 32, WHITE, BLACK, INVERT, WHITE, BLACK, INVERT, WHITE, BLACK)
                .impact(4160, 60, 33, INVERT, BLACK)
                .lines(3300, 600, 0xE0B0FF)
                .lines(3890, 400, 0xFFFFFF)
                .title(3890, 5400, "title.hollowburst.purple.kanji", "title.hollowburst.purple.name", PURPLE)
                .sub(150, 1250, "subtitle.hollowburst.purple_1", WHITE_TEXT, 1.5f, false)
                .sub(1450, 2950, "subtitle.hollowburst.purple_2", WHITE_TEXT, 1.4f, false)
                .sub(3050, 3880, "subtitle.hollowburst.purple_3", PURPLE, 2.0f, true)
                .sub(5000, 6000, "subtitle.hollowburst.purple_4", WHITE_TEXT, 1.5f, false);
    }

    private CutsceneDefs() {}
}
