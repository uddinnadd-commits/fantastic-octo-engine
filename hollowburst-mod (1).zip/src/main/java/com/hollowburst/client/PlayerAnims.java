package com.hollowburst.client;

import com.hollowburst.CutsceneType;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel.ArmPose;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.client.event.RenderLivingEvent;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.DoubleUnaryOperator;

/**
 * Custom body choreography for the caster, visible to everyone who can see them.
 *
 * Each clip drives: hover (lift), lean, twist, roll and tremble of the whole body around the hips
 * (applied to the render matrix, so armour, held items and the cape all follow), plus a schedule of
 * arm poses (hand to the eye, arms thrust forward, sword overhead, both hands together).
 */
final class PlayerAnims {

    private record ArmKey(long from, long to, ArmPose right, ArmPose left) {}

    private record Clip(long duration,
                        DoubleUnaryOperator lift,
                        DoubleUnaryOperator lean,
                        DoubleUnaryOperator twist,
                        DoubleUnaryOperator roll,
                        DoubleUnaryOperator tremble,
                        List<ArmKey> arms) {}

    private record Active(CutsceneType type, long startMs) {}

    private static final Map<CutsceneType, Clip> CLIPS = new EnumMap<>(CutsceneType.class);
    private static final Map<Integer, Active> ACTIVE = new HashMap<>();
    private static final Set<Integer> PUSHED = new HashSet<>();

    static {
        // ---- Red: hand to the eye, pull back, thrust, then tumble upward
        List<ArmKey> red = new ArrayList<>();
        red.add(new ArmKey(0, 800, ArmPose.SPYGLASS, null));
        red.add(new ArmKey(800, 2900, ArmPose.BOW_AND_ARROW, ArmPose.BOW_AND_ARROW));
        CLIPS.put(CutsceneType.BURST, new Clip(2900,
                Curves.keys(0, 0, 900, 0.25, 1190, 0.30, 1200, 0.0),
                Curves.keys(0, 0, 600, -14, 1100, -24, 1190, -24, 1230, 30, 1500, 10, 2400, -35, 2900, -50),
                Curves.keys(0, 0, 1100, 0, 1250, -25, 2000, 15, 2900, 0),
                Curves.keys(0, 0, 1250, 0, 1500, 12, 2900, -8),
                Curves.keys(0, 0, 700, 0.0, 1150, 0.03, 1200, 0.0),
                red));

        // ---- Blue: sword raised overhead, arm across, slashing lunge, recover
        List<ArmKey> blue = new ArrayList<>();
        blue.add(new ArmKey(0, 1250, ArmPose.THROW_SPEAR, null));
        blue.add(new ArmKey(1250, 1900, ArmPose.BLOCK, null));
        blue.add(new ArmKey(1900, 2500, ArmPose.BOW_AND_ARROW, ArmPose.BOW_AND_ARROW));
        CLIPS.put(CutsceneType.SWORD, new Clip(3900,
                Curves.keys(0, 0, 1250, 0.35, 1900, 0.35, 2000, 0.15, 3000, 0.15, 3300, 0),
                Curves.keys(0, 0, 1000, -18, 1250, -22, 1900, -22, 2000, 38, 2400, 30, 3300, 0),
                Curves.keys(0, 0, 1250, 10, 1900, -30, 2000, 55, 2400, 40, 3300, 0),
                Curves.keys(0, 0, 1900, 0, 2050, -10, 2600, 0),
                Curves.keys(0, 0, 1200, 0.0, 1250, 0.02, 1900, 0.02, 2000, 0.0),
                blue));

        // ---- Purple: hand sign, both hands together to hold the orbs, thrust, recoil
        List<ArmKey> purple = new ArrayList<>();
        purple.add(new ArmKey(0, 1500, ArmPose.SPYGLASS, null));
        purple.add(new ArmKey(1500, 3000, ArmPose.CROSSBOW_HOLD, ArmPose.CROSSBOW_HOLD));
        purple.add(new ArmKey(3000, 5000, ArmPose.BOW_AND_ARROW, ArmPose.BOW_AND_ARROW));
        CLIPS.put(CutsceneType.MACE, new Clip(6300,
                Curves.keys(0, 0, 1500, 0.2, 3000, 0.5, 3900, 0.5, 4200, 0.4, 5000, 0.2, 5400, 0),
                Curves.keys(0, 0, 800, -10, 1500, -10, 3000, -12, 3010, 22, 3900, 22, 3910, -28, 4200, -20, 5000, -6, 6300, 0),
                Curves.keys(0, 0, 3900, 0, 4100, -18, 5000, 0),
                Curves.keys(0, 0, 3000, 0, 3910, 8, 4300, -4, 5000, 0),
                Curves.keys(0, 0, 2500, 0.0, 3000, 0.01, 3900, 0.04, 5000, 0),
                purple));
    }

    static void start(int entityId, CutsceneType type) {
        ACTIVE.put(entityId, new Active(type, System.nanoTime() / 1_000_000L));
    }

    static void pre(RenderLivingEvent.Pre<?, ?> e) {
        LivingEntity ent = e.getEntity();
        Active a = ACTIVE.get(ent.getId());
        if (a == null) return;

        Clip c = CLIPS.get(a.type());
        long ms = System.nanoTime() / 1_000_000L - a.startMs();
        if (c == null || ms > c.duration()) {
            ACTIVE.remove(ent.getId());
            return;
        }

        if (e.getRenderer().getModel() instanceof PlayerModel<?> pm) {
            for (ArmKey k : c.arms()) {
                if (ms >= k.from() && ms < k.to()) {
                    if (k.right() != null) pm.rightArmPose = k.right();
                    if (k.left() != null) pm.leftArmPose = k.left();
                }
            }
        }

        float body = Mth.rotLerp(e.getPartialTick(), ent.yBodyRotO, ent.yBodyRot);
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        PUSHED.add(ent.getId());

        double tm = c.tremble().applyAsDouble(ms);
        if (tm > 0.0) {
            ps.translate(Math.sin(ms * 0.9) * tm, 0.0, Math.cos(ms * 1.3) * tm);
        }
        // work in the body's own frame: forward = +Z, pivot at the hips
        ps.mulPose(Axis.YP.rotationDegrees(-body));
        ps.translate(0.0, c.lift().applyAsDouble(ms) + 0.9, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees((float) c.twist().applyAsDouble(ms)));
        ps.mulPose(Axis.XP.rotationDegrees((float) c.lean().applyAsDouble(ms)));
        ps.mulPose(Axis.ZP.rotationDegrees((float) c.roll().applyAsDouble(ms)));
        ps.translate(0.0, -0.9, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(body));
    }

    static void post(RenderLivingEvent.Post<?, ?> e) {
        if (PUSHED.remove(e.getEntity().getId())) {
            e.getPoseStack().popPose();
        }
    }

    private PlayerAnims() {}
}
