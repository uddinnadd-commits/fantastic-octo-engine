package com.hollowburst.client;

import net.minecraft.client.CameraType;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Function;

/** Describes one cutscene: camera shots, subtitles, title cards, impact frames and camera curves. */
public final class CutsceneDef {

    /** Impact frame styles. */
    public static final int INVERT = 0; // the world, colour-inverted
    public static final int WHITE = 1;  // white screen, black ink
    public static final int BLACK = 2;  // black screen, white ink

    /** A subtitle line. langKey is looked up in en_us.json. */
    public record Sub(long start, long end, String langKey, int rgb, float scale, boolean bold) {}

    /** A burst of anime-style impact frames. frames[i] is the style of frame i, each lasting frameMs. */
    public record Impact(long at, int[] frames, int frameMs, long seed) {}

    /** Fallback camera change, used only if the free camera rig could not start. */
    public record Cut(long at, CameraType camera) {}

    /** A full-screen colour flash that fades out. */
    public record Flash(long at, long duration, int rgb) {}

    /** A scripted free-camera shot. */
    public record Shot(long start, long end, Function<ShotEnv, CamPose> fn) {}

    /** A giant kanji title card that slams onto the screen, with a technique name under it. */
    public record Title(long start, long end, String kanjiKey, String nameKey, int rgb) {}

    /** Speed-line overlay (motion lines) for fast moves. */
    public record Lines(long at, long duration, int rgb) {}

    public final long durationMs;
    public long freezeMs;
    public final List<Sub> subs = new ArrayList<>();
    public final List<Impact> impacts = new ArrayList<>();
    public final List<Cut> cuts = new ArrayList<>();
    public final List<Flash> flashes = new ArrayList<>();
    public final List<Shot> shots = new ArrayList<>();
    public final List<Title> titles = new ArrayList<>();
    public final List<Lines> lines = new ArrayList<>();

    public DoubleUnaryOperator fov = t -> 1.0;        // extra FOV multiplier ("zoom punches")
    public DoubleUnaryOperator roll = t -> 0.0;       // degrees
    public DoubleUnaryOperator shake = t -> 0.0;      // degrees of amplitude
    public DoubleUnaryOperator tintAlpha = t -> 0.0;  // 0..1
    public int tintRgb = 0xFFFFFF;

    public CutsceneDef(long durationMs) {
        this.durationMs = durationMs;
    }

    public CutsceneDef freeze(long ms) {
        this.freezeMs = ms;
        return this;
    }

    public CutsceneDef sub(long start, long end, String langKey, int rgb, float scale, boolean bold) {
        subs.add(new Sub(start, end, langKey, rgb, scale, bold));
        return this;
    }

    public CutsceneDef impact(long at, int frameMs, long seed, int... frames) {
        impacts.add(new Impact(at, frames, frameMs, seed));
        return this;
    }

    public CutsceneDef cut(long at, CameraType camera) {
        cuts.add(new Cut(at, camera));
        return this;
    }

    public CutsceneDef flash(long at, long duration, int rgb) {
        flashes.add(new Flash(at, duration, rgb));
        return this;
    }

    public CutsceneDef shot(long start, long end, Function<ShotEnv, CamPose> fn) {
        shots.add(new Shot(start, end, fn));
        return this;
    }

    public CutsceneDef title(long start, long end, String kanjiKey, String nameKey, int rgb) {
        titles.add(new Title(start, end, kanjiKey, nameKey, rgb));
        return this;
    }

    public CutsceneDef lines(long at, long duration, int rgb) {
        lines.add(new Lines(at, duration, rgb));
        return this;
    }

    public CutsceneDef fov(DoubleUnaryOperator c) {
        this.fov = c;
        return this;
    }

    public CutsceneDef roll(DoubleUnaryOperator c) {
        this.roll = c;
        return this;
    }

    public CutsceneDef shake(DoubleUnaryOperator c) {
        this.shake = c;
        return this;
    }

    public CutsceneDef tint(int rgb, DoubleUnaryOperator alpha) {
        this.tintRgb = rgb;
        this.tintAlpha = alpha;
        return this;
    }
}
