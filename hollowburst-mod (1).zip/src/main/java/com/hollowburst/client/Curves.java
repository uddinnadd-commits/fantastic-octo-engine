package com.hollowburst.client;

import java.util.function.DoubleUnaryOperator;

/** Keyframe helpers. All times are in milliseconds since the cutscene started. */
final class Curves {

    /**
     * Smooth keyframe curve. Pass alternating time, value pairs in ascending time order:
     * keys(0, 1.0, 500, 0.5, 900, 1.2). Use two keys 1 ms apart for a hard snap.
     */
    static DoubleUnaryOperator keys(double... tv) {
        final double[] k = tv.clone();
        final int n = k.length / 2;
        return t -> {
            if (t <= k[0]) return k[1];
            for (int i = 0; i < n - 1; i++) {
                double t0 = k[2 * i];
                double v0 = k[2 * i + 1];
                double t1 = k[2 * i + 2];
                double v1 = k[2 * i + 3];
                if (t < t1) {
                    double x = (t - t0) / Math.max(1.0E-6, t1 - t0);
                    x = x * x * (3.0 - 2.0 * x);
                    return v0 + (v1 - v0) * x;
                }
            }
            return k[2 * n - 1];
        };
    }

    static double clamp01(double x) {
        return x < 0.0 ? 0.0 : (x > 1.0 ? 1.0 : x);
    }

    static double smooth(double x) {
        x = clamp01(x);
        return x * x * (3.0 - 2.0 * x);
    }

    private Curves() {}
}
