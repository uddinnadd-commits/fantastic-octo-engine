package com.hollowburst.client;

import com.hollowburst.CutsceneType;
import net.minecraft.world.phys.Vec3;

/** Everything the client needs to know about one running cutscene's surroundings. */
public record CutsceneCtx(
        CutsceneType type,
        int attackerId,
        int targetId,
        Vec3 focus,      // target centre (or your chest for the C burst)
        Vec3 orb,        // orb centre (Hollow Purple)
        boolean cinematic,
        Vec3 fwd,        // horizontal unit vector: where the action points
        Vec3 side,       // horizontal unit vector perpendicular to fwd
        Vec3 origin) {   // attacker position when the cutscene started
}
