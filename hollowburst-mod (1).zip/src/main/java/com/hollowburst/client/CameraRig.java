package com.hollowburst.client;

import com.hollowburst.HollowBurstMod;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * A real free camera. During a cutscene the game's camera entity is swapped for an invisible
 * client-side Marker that we place and aim every frame from the scripted shots, so the camera
 * can orbit, crane, whip and push in anywhere, instead of being stuck to the player.
 */
final class CameraRig {
    private static Marker cam;
    private static boolean active;
    private static float startEye;
    private static int ticks;
    private static CamPose current;
    private static CutsceneDef.Shot lastShot;

    static boolean isActive() {
        return active;
    }

    static double fovMult() {
        return current == null ? 1.0 : current.fov();
    }

    static double roll() {
        return current == null ? 0.0 : current.roll();
    }

    static boolean start(Minecraft mc) {
        if (active) return true;
        try {
            if (mc.level == null || mc.player == null) return false;
            cam = new Marker(EntityType.MARKER, mc.level);
            startEye = mc.player.getEyeHeight();
            ticks = 0;
            current = null;
            lastShot = null;
            cam.moveTo(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ(), mc.player.getYRot(), mc.player.getXRot());
            mc.setCameraEntity(cam);
            mc.options.setCameraType(CameraType.FIRST_PERSON);
            active = true;
            return true;
        } catch (Throwable t) {
            HollowBurstMod.LOGGER.warn("Hollow Burst: free camera unavailable, using the fallback camera", t);
            cleanup(mc);
            return false;
        }
    }

    static void tick() {
        if (active) ticks++;
    }

    static void update(Minecraft mc, CutsceneDef def, CutsceneCtx ctx, long t, float partial) {
        if (!active || cam == null || mc.level == null) return;
        try {
            Entity attacker = mc.level.getEntity(ctx.attackerId());
            Vec3 feet = attacker != null ? attacker.getPosition(partial) : ctx.origin();
            Vec3 head = attacker != null ? attacker.getEyePosition(partial) : feet.add(0, 1.62, 0);

            CutsceneDef.Shot shot = null;
            for (CutsceneDef.Shot s : def.shots) {
                if (t >= s.start() && t < s.end()) {
                    shot = s;
                    break;
                }
            }
            if (shot == null) {
                if (lastShot == null) return; // nothing to show yet
                shot = lastShot;
                t = shot.end() - 1;
            } else {
                lastShot = shot;
            }

            double u = (t - shot.start()) / (double) Math.max(1L, shot.end() - shot.start());
            ShotEnv env = new ShotEnv(u, t, ctx, feet, head);
            CamPose p = shot.fn().apply(env);

            Vec3 pos = clip(mc, p.look(), p.pos());
            current = new CamPose(pos, p.look(), p.fov(), p.roll());

            double dx = p.look().x - pos.x;
            double dy = p.look().y - pos.y;
            double dz = p.look().z - pos.z;
            double horiz = Math.sqrt(dx * dx + dz * dz);
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
            pitch = Mth.clamp(pitch, -89.9F, 89.9F);

            // the game eases the camera's eye height towards the Marker's (0) over a few ticks;
            // compensate so the shot lands exactly where we aimed it
            double eh = startEye * Math.pow(0.5, ticks + partial);
            cam.moveTo(pos.x, pos.y - eh, pos.z, yaw, pitch);
        } catch (Throwable ex) {
            HollowBurstMod.LOGGER.warn("Hollow Burst: camera rig failed, switching it off", ex);
            stop(mc);
        }
    }

    /** Pulls the camera in front of any wall between it and the thing it is looking at. */
    private static Vec3 clip(Minecraft mc, Vec3 look, Vec3 pos) {
        if (mc.level == null || mc.player == null || look.distanceToSqr(pos) < 0.04) return pos;
        BlockHitResult hit = mc.level.clip(new ClipContext(look, pos,
                ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, mc.player));
        if (hit.getType() == HitResult.Type.BLOCK) {
            Vec3 loc = hit.getLocation();
            Vec3 back = look.subtract(loc);
            double len = back.length();
            return len < 0.3 ? loc : loc.add(back.scale(0.25 / len));
        }
        return pos;
    }

    static void stop(Minecraft mc) {
        cleanup(mc);
    }

    private static void cleanup(Minecraft mc) {
        if (cam != null && mc.player != null) {
            mc.setCameraEntity(mc.player);
        }
        cam = null;
        active = false;
        current = null;
        lastShot = null;
    }

    private CameraRig() {}
}
