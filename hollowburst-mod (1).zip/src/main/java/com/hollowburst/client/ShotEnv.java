package com.hollowburst.client;

import net.minecraft.world.phys.Vec3;

/** Everything a camera shot needs to compute its pose for the current frame. */
public final class ShotEnv {
    public static final Vec3 UP = new Vec3(0, 1, 0);

    public final double u;   // progress through this shot, 0..1
    public final double k;   // the same, eased (smoothstep)
    public final double t;   // global cutscene time in ms
    public final CutsceneCtx ctx;
    public final Vec3 feet;  // attacker, live
    public final Vec3 head;
    public final Vec3 chest;
    public final Vec3 focus;
    public final Vec3 orb;
    public final Vec3 fwd;
    public final Vec3 side;
    public final Vec3 origin;

    ShotEnv(double u, double t, CutsceneCtx ctx, Vec3 feet, Vec3 head) {
        this.u = Curves.clamp01(u);
        this.k = Curves.smooth(this.u);
        this.t = t;
        this.ctx = ctx;
        this.feet = feet;
        this.head = head;
        this.chest = feet.add(0, (head.y - feet.y) * 0.62, 0);
        this.focus = ctx.focus();
        this.orb = ctx.orb();
        this.fwd = ctx.fwd();
        this.side = ctx.side();
        this.origin = ctx.origin();
    }

    /**
     * A point on a circle around "center". Angle 0 = directly behind the action (looking along fwd),
     * 90 = to the side, 180 = in front, looking back at it.
     */
    public Vec3 around(Vec3 center, double angleDeg, double radius, double height) {
        double a = Math.toRadians(angleDeg);
        Vec3 dir = fwd.scale(-Math.cos(a)).add(side.scale(Math.sin(a)));
        return center.add(dir.scale(radius)).add(0, height, 0);
    }

    public static double lerp(double a, double b, double x) {
        return a + (b - a) * x;
    }

    public static Vec3 mix(Vec3 a, Vec3 b, double x) {
        return a.add(b.subtract(a).scale(x));
    }
}
