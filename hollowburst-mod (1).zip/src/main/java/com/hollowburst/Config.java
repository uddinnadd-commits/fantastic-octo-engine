package com.hollowburst;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS = B
            .comment("Seconds before Hollow Burst can be used again.")
            .defineInRange("cooldownSeconds", 20, 0, 3600);

    public static final ForgeConfigSpec.IntValue PRIMED_SECONDS = B
            .comment("How long after the launch a sword or mace hit still triggers a cutscene.")
            .defineInRange("primedSeconds", 20, 3, 120);

    public static final ForgeConfigSpec.DoubleValue LAUNCH_SPEED = B
            .comment("Upward launch speed. 2.2 is roughly 30 blocks up.")
            .defineInRange("launchSpeed", 2.2D, 0.5D, 6.0D);

    public static final ForgeConfigSpec.DoubleValue BURST_DAMAGE = B
            .comment("Damage dealt to things near you when you detonate.")
            .defineInRange("burstDamage", 10.0D, 0.0D, 1000.0D);

    public static final ForgeConfigSpec.DoubleValue SWORD_DAMAGE = B
            .comment("Extra damage to the target of the sword cutscene (Lapse: Blue).")
            .defineInRange("swordDamage", 30.0D, 0.0D, 10000.0D);

    public static final ForgeConfigSpec.DoubleValue MACE_DAMAGE = B
            .comment("Extra damage to the target of the mace cutscene (Hollow Purple).")
            .defineInRange("maceDamage", 60.0D, 0.0D, 10000.0D);

    public static final ForgeConfigSpec.BooleanValue DESTROY_BLOCKS = B
            .comment("If true the explosions also destroy blocks. Off by default.")
            .define("destroyBlocks", false);

    public static final ForgeConfigSpec SPEC = B.build();

    private Config() {}
}
